# def is_hex(num)
#   !!(/(0[xX])?[0-9a-fA-F]+/ =~ num)
# end
#
# puts is_hex('0acdadecf822eeff32aca5830e438cb54aa722e3')


# def rmp(a):
#   if a == 0:
#     return 1
#   if a == 1:
#    return 3
#
#   # return 3 * rmp(a-1) - rmp(a-2);
#   stored_rmp_arr = [1, 3]
#   curr = 1
#   while curr < a:
#     stored_rmp_arr.append(3 * stored_rmp_arr[curr] - stored_rmp_arr[curr-1])
#     curr = curr + 1
#   return stored_rmp_arr[-1]
#
# result = rmp(28)
# print(result);
