class ApplicationController < Sinatra::Base

  configure do
    set :views, "app/views"
    set :public_dir, "public"
  end

  require_relative "../models/post.rb"

  Tilt.register Tilt::ERBTemplate, 'html.erb'

  get "/" do
    @posts = Post::DB
    @comments = Post::COMMENTS
    erb :posts
  end
end
